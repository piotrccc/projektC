#ifndef ICMP_LIB_H_
#define ICMP_LIB_H_

void CreateUdpPacket ( unsigned char * datagram );

#endif /* ICMP_LIB_H_ */
